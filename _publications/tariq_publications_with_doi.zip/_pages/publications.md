---
layout: archive
title: "Publications"
permalink: /publications/
author_profile: true
---

This page lists my published papers and manuscripts under review, including authors, venues, publishers, indexing information, roles, and DOI links where available.

## Journal Articles

### Swin Transformer with Attention Mechanism: A Novel Framework for Person Re-Identification

**Authors:** Tariq Ali Arain, Pengcheng Zhang, Qing Meng, Abdullahi Uwaisu Muhammad  
**Journal:** Pattern Analysis and Applications  
**Publisher:** Springer London  
**Year:** 2025  
**Indexing:** SCIE  
**Role:** First Author  
**Link:** [DOI: 10.1007/s10044-025-01466-1](https://doi.org/10.1007/s10044-025-01466-1)

### An Adaptive Cross-Resolution Network for Low-Resolution Person Re-Identification

**Authors:** Tariq Ali Arain, Pengcheng Zhang, Sehrish Mazhar, Qing Meng  
**Journal:** International Journal of Pattern Recognition and Artificial Intelligence  
**Publisher:** World Scientific Publishing Company  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** First Author  
**Link:** [DOI: 10.1142/S021800142650014X](https://doi.org/10.1142/S021800142650014X)

### Attention-Guided Multi-Feature Fusion Hybrid Architecture for Person Re-Identification in Smart Surveillance Systems

**Authors:** Tariq Ali Arain, Pengcheng Zhang, Sehrish Mazhar, Qing Meng, Imran Ali Soomro  
**Journal:** Image and Vision Computing  
**Publisher:** Elsevier  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** First Author  
**Link:** [DOI: 10.1016/j.imavis.2026.106014](https://doi.org/10.1016/j.imavis.2026.106014)

### A Novel Multi-Objective Optimization Approach for Ticket Assignment in Large Data Centers

**Authors:** Tariq Ali Arain and Sehrish Mazhar  
**Journal:** Cluster Computing  
**Publisher:** Springer  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** Corresponding Author and First Author  
**Link:** Accepted on 6 June 2026

## Conference Papers

### Multi-objective Optimization of Ticket Assignment Problem in Large Data Centers

**Authors:** Tariq Ali Arain, Xiangjie Huang, Zhicheng Cai, Jian Xu  
**Conference:** CCF Conference on Computer Supported Cooperative Work and Social Computing (ChineseCSCW 2021)  
**Publisher:** Springer Nature Singapore  
**Year:** 2022  
**Indexing:** EI / Scopus  
**Role:** First Author  
**Link:** [DOI: 10.1007/978-981-19-4549-6_4](https://doi.org/10.1007/978-981-19-4549-6_4)

### Optimizing Service Placement in Fog Environments with Deep Reinforcement Learning

**Authors:** Wei Liu, Qin Xie, Tariq Ali Arain, Usama Ali  
**Conference:** ICSS 2025  
**Publisher:** Springer Nature  
**Year:** 2025  
**Indexing:** EI / Scopus  
**Role:** Co-Author  
**Link:** [DOI: 10.1007/978-981-95-1581-3_18](https://doi.org/10.1007/978-981-95-1581-3_18)

### Efficient Workload Prediction Model for Containerized Cloud

**Authors:** Tianqi Xie, Yunfei Zhang, Changhong Tai, Tariq Ali Arain, Usama Ali  
**Conference:** ICSS 2025  
**Publisher:** Springer Nature Singapore  
**Year:** 2025  
**Indexing:** EI / Scopus  
**Role:** Co-Author  
**Link:** [DOI: 10.1007/978-981-95-1581-3_19](https://doi.org/10.1007/978-981-95-1581-3_19)

### FedQR: Communication-Efficient Federated Learning via QR Factorization

**Authors:** Abdoul Fatakhou Ba, Yingchi Mao, Hamza Djigal, Abdullahi Uwaisu Muhammad, Tariq Ali Arain, Siaka Konate  
**Conference:** ICONIP 2024  
**Publisher:** Springer Nature Singapore  
**Year:** 2024  
**Indexing:** EI / Scopus  
**Role:** Co-Author  
**Link:** [DOI: 10.1007/978-981-96-6951-6_30](https://doi.org/10.1007/978-981-96-6951-6_30)

## Manuscripts Under Review

### A Novel Approach to Safe and Efficient USV Path Planning in Complex Environments

**Authors:** Sehrish Mazhar, Tariq Ali Arain, Rizwan Badar Baloch, Nejib Ghazouani, Tariq Alqubaysi, Monji Mohamed Zaidi, Jahangir Badar  
**Target Journal:** Scientific Reports  
**Publisher:** Springer  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** Second Author  
**Status:** Revision submitted after peer review (2nd round)  
**DOI/Link:** To be added

### Beyond Benchmark Accuracy: A Robustness-Oriented Review of Occluded Person Re-Identification Under Structured Uncertainty

**Authors:** Sehrish Mazhar, Tariq Ali Arain, Benish Mazhar  
**Target Journal:** IEEE Transactions on Pattern Analysis and Machine Intelligence  
**Publisher:** IEEE  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** Corresponding Author  
**Status:** Under peer review  
**DOI/Link:** To be added

### Occlusion-Disentangled Gated Attention Network for Person Re-Identification in Smart Surveillance Systems

**Authors:** Tariq Ali Arain and Sehrish Mazhar  
**Target Journal:** Information Fusion  
**Publisher:** Elsevier  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** Corresponding Author  
**Status:** Under peer review  
**DOI/Link:** To be added

