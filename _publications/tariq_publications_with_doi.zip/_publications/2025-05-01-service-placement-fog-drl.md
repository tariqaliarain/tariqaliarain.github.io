---
title: "Optimizing Service Placement in Fog Environments with Deep Reinforcement Learning"
collection: publications
category: conferences
permalink: /publication/service-placement-fog-drl
excerpt: "A deep reinforcement learning approach for optimizing service placement in fog computing environments."
date: 2025-05-01
venue: "ICSS 2025"
paperurl: "https://doi.org/10.1007/978-981-95-1581-3_18"
citation: "Wei Liu, Qin Xie, Tariq Ali Arain, Usama Ali. (2025). Optimizing Service Placement in Fog Environments with Deep Reinforcement Learning. ICSS 2025. https://doi.org/10.1007/978-981-95-1581-3_18"
---

**Authors:** Wei Liu, Qin Xie, Tariq Ali Arain, Usama Ali  
**Journal/Conference:** ICSS 2025  
**Publisher:** Springer Nature  
**Year:** 2025  
**Indexing:** EI / Scopus  
**Role:** Co-Author  
**Status:** Published  
**DOI:** [10.1007/978-981-95-1581-3_18](https://doi.org/10.1007/978-981-95-1581-3_18)  

### Summary

A deep reinforcement learning approach for optimizing service placement in fog computing environments.
