---
title: "An Adaptive Cross-Resolution Network for Low-Resolution Person Re-Identification"
collection: publications
category: manuscripts
permalink: /publication/adaptive-cross-resolution-reid
excerpt: "A cross-resolution representation learning method for improving low-resolution person re-identification."
date: 2026-01-01
venue: "International Journal of Pattern Recognition and Artificial Intelligence"
paperurl: "https://doi.org/10.1142/S021800142650014X"
citation: "Tariq Ali Arain, Pengcheng Zhang, Sehrish Mazhar, Qing Meng. (2026). An Adaptive Cross-Resolution Network for Low-Resolution Person Re-Identification. International Journal of Pattern Recognition and Artificial Intelligence. https://doi.org/10.1142/S021800142650014X"
---

**Authors:** Tariq Ali Arain, Pengcheng Zhang, Sehrish Mazhar, Qing Meng  
**Journal/Conference:** International Journal of Pattern Recognition and Artificial Intelligence  
**Publisher:** World Scientific Publishing Company  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** First Author  
**Status:** Published  
**DOI:** [10.1142/S021800142650014X](https://doi.org/10.1142/S021800142650014X)  

### Summary

A cross-resolution representation learning method for improving low-resolution person re-identification.
