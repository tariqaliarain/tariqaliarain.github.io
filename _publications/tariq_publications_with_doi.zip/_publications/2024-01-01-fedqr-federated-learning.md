---
title: "FedQR: Communication-Efficient Federated Learning via QR Factorization"
collection: publications
category: conferences
permalink: /publication/fedqr-federated-learning
excerpt: "A communication-efficient federated learning method based on QR factorization."
date: 2024-01-01
venue: "ICONIP 2024"
paperurl: "https://doi.org/10.1007/978-981-96-6951-6_30"
citation: "Abdoul Fatakhou Ba, Yingchi Mao, Hamza Djigal, Abdullahi Uwaisu Muhammad, Tariq Ali Arain, Siaka Konate. (2024). FedQR: Communication-Efficient Federated Learning via QR Factorization. ICONIP 2024. https://doi.org/10.1007/978-981-96-6951-6_30"
---

**Authors:** Abdoul Fatakhou Ba, Yingchi Mao, Hamza Djigal, Abdullahi Uwaisu Muhammad, Tariq Ali Arain, Siaka Konate  
**Journal/Conference:** ICONIP 2024  
**Publisher:** Springer Nature Singapore  
**Year:** 2024  
**Indexing:** EI / Scopus  
**Role:** Co-Author  
**Status:** Published  
**DOI:** [10.1007/978-981-96-6951-6_30](https://doi.org/10.1007/978-981-96-6951-6_30)  

### Summary

A communication-efficient federated learning method based on QR factorization.
