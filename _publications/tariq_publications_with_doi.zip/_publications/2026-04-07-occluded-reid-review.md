---
title: "Beyond Benchmark Accuracy: A Robustness-Oriented Review of Occluded Person Re-Identification Under Structured Uncertainty"
collection: publications
category: manuscripts
permalink: /publication/occluded-reid-review-under-review
excerpt: "A robustness-oriented review of occluded person re-identification under structured uncertainty."
date: 2026-04-07
venue: "IEEE Transactions on Pattern Analysis and Machine Intelligence"
paperurl: ""
citation: "Sehrish Mazhar, Tariq Ali Arain, Benish Mazhar. (2026). Beyond Benchmark Accuracy: A Robustness-Oriented Review of Occluded Person Re-Identification Under Structured Uncertainty. IEEE Transactions on Pattern Analysis and Machine Intelligence. Under peer review."
---

**Authors:** Sehrish Mazhar, Tariq Ali Arain, Benish Mazhar  
**Journal/Conference:** IEEE Transactions on Pattern Analysis and Machine Intelligence  
**Publisher:** IEEE  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** Corresponding Author  
**Status:** Under peer review  
**DOI/Link:** To be added  

### Summary

A robustness-oriented review of occluded person re-identification under structured uncertainty.
