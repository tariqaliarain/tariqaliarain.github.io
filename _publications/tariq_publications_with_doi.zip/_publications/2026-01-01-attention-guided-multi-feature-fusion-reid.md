---
title: "Attention-Guided Multi-Feature Fusion Hybrid Architecture for Person Re-Identification in Smart Surveillance Systems"
collection: publications
category: manuscripts
permalink: /publication/attention-guided-multi-feature-fusion-reid
excerpt: "A hybrid fusion-attention architecture for robust person re-identification in smart surveillance environments."
date: 2026-01-01
venue: "Image and Vision Computing"
paperurl: "https://doi.org/10.1016/j.imavis.2026.106014"
citation: "Tariq Ali Arain, Pengcheng Zhang, Sehrish Mazhar, Qing Meng, Imran Ali Soomro. (2026). Attention-Guided Multi-Feature Fusion Hybrid Architecture for Person Re-Identification in Smart Surveillance Systems. Image and Vision Computing. https://doi.org/10.1016/j.imavis.2026.106014"
---

**Authors:** Tariq Ali Arain, Pengcheng Zhang, Sehrish Mazhar, Qing Meng, Imran Ali Soomro  
**Journal/Conference:** Image and Vision Computing  
**Publisher:** Elsevier  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** First Author  
**Status:** Published  
**DOI:** [10.1016/j.imavis.2026.106014](https://doi.org/10.1016/j.imavis.2026.106014)  

### Summary

A hybrid fusion-attention architecture for robust person re-identification in smart surveillance environments.
