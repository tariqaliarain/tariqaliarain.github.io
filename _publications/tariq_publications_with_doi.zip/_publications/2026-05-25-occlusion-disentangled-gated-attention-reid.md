---
title: "Occlusion-Disentangled Gated Attention Network for Person Re-Identification in Smart Surveillance Systems"
collection: publications
category: manuscripts
permalink: /publication/occlusion-disentangled-gated-attention-reid-under-review
excerpt: "A manuscript proposing an occlusion-disentangled gated attention network for person re-identification."
date: 2026-05-25
venue: "Information Fusion"
paperurl: ""
citation: "Tariq Ali Arain and Sehrish Mazhar. (2026). Occlusion-Disentangled Gated Attention Network for Person Re-Identification in Smart Surveillance Systems. Information Fusion. Under peer review."
---

**Authors:** Tariq Ali Arain and Sehrish Mazhar  
**Journal/Conference:** Information Fusion  
**Publisher:** Elsevier  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** Corresponding Author  
**Status:** Under peer review  
**DOI/Link:** To be added  

### Summary

A manuscript proposing an occlusion-disentangled gated attention network for person re-identification.
