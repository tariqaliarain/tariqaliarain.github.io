---
title: "A Novel Approach to Safe and Efficient USV Path Planning in Complex Environments"
collection: publications
category: manuscripts
permalink: /publication/usv-path-planning-under-review
excerpt: "A manuscript on safe and efficient unmanned surface vehicle path planning in complex environments."
date: 2026-04-20
venue: "Scientific Reports"
paperurl: ""
citation: "Sehrish Mazhar, Tariq Ali Arain, Rizwan Badar Baloch, Nejib Ghazouani, Tariq Alqubaysi, Monji Mohamed Zaidi, Jahangir Badar. (2026). A Novel Approach to Safe and Efficient USV Path Planning in Complex Environments. Scientific Reports. Revision submitted after peer review (2nd round)."
---

**Authors:** Sehrish Mazhar, Tariq Ali Arain, Rizwan Badar Baloch, Nejib Ghazouani, Tariq Alqubaysi, Monji Mohamed Zaidi, Jahangir Badar  
**Journal/Conference:** Scientific Reports  
**Publisher:** Springer  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** Second Author  
**Status:** Revision submitted after peer review (2nd round)  
**DOI/Link:** To be added  

### Summary

A manuscript on safe and efficient unmanned surface vehicle path planning in complex environments.
