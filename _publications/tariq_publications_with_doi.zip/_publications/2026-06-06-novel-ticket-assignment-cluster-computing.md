---
title: "A Novel Multi-Objective Optimization Approach for Ticket Assignment in Large Data Centers"
collection: publications
category: manuscripts
permalink: /publication/novel-ticket-assignment-cluster-computing
excerpt: "A multi-objective optimization method for ticket assignment in large data centers, focusing on scheduling, resource allocation, and performance-aware decision making."
date: 2026-06-06
venue: "Cluster Computing"
paperurl: ""
citation: "Tariq Ali Arain and Sehrish Mazhar. (2026). A Novel Multi-Objective Optimization Approach for Ticket Assignment in Large Data Centers. Cluster Computing. Accepted on 6 June 2026."
---

**Authors:** Tariq Ali Arain and Sehrish Mazhar  
**Journal/Conference:** Cluster Computing  
**Publisher:** Springer  
**Year:** 2026  
**Indexing:** SCIE  
**Role:** Corresponding Author and First Author  
**Status:** Accepted on 6 June 2026  
**DOI/Link:** To be added  

### Summary

A multi-objective optimization method for ticket assignment in large data centers, focusing on scheduling, resource allocation, and performance-aware decision making.
