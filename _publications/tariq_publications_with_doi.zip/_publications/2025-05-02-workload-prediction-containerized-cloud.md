---
title: "Efficient Workload Prediction Model for Containerized Cloud"
collection: publications
category: conferences
permalink: /publication/workload-prediction-containerized-cloud
excerpt: "A workload prediction model for containerized cloud environments, supporting efficient resource management."
date: 2025-05-02
venue: "ICSS 2025"
paperurl: "https://doi.org/10.1007/978-981-95-1581-3_19"
citation: "Tianqi Xie, Yunfei Zhang, Changhong Tai, Tariq Ali Arain, Usama Ali. (2025). Efficient Workload Prediction Model for Containerized Cloud. ICSS 2025. https://doi.org/10.1007/978-981-95-1581-3_19"
---

**Authors:** Tianqi Xie, Yunfei Zhang, Changhong Tai, Tariq Ali Arain, Usama Ali  
**Journal/Conference:** ICSS 2025  
**Publisher:** Springer Nature Singapore  
**Year:** 2025  
**Indexing:** EI / Scopus  
**Role:** Co-Author  
**Status:** Published  
**DOI:** [10.1007/978-981-95-1581-3_19](https://doi.org/10.1007/978-981-95-1581-3_19)  

### Summary

A workload prediction model for containerized cloud environments, supporting efficient resource management.
