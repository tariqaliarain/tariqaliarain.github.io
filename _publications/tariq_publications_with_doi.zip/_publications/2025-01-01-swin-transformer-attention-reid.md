---
title: "Swin Transformer with Attention Mechanism: A Novel Framework for Person Re-Identification"
collection: publications
category: manuscripts
permalink: /publication/swin-transformer-attention-reid
excerpt: "A transformer-based framework with attention mechanisms for robust person re-identification under challenging visual conditions."
date: 2025-01-01
venue: "Pattern Analysis and Applications"
paperurl: "https://doi.org/10.1007/s10044-025-01466-1"
citation: "Tariq Ali Arain, Pengcheng Zhang, Qing Meng, Abdullahi Uwaisu Muhammad. (2025). Swin Transformer with Attention Mechanism: A Novel Framework for Person Re-Identification. Pattern Analysis and Applications. https://doi.org/10.1007/s10044-025-01466-1"
---

**Authors:** Tariq Ali Arain, Pengcheng Zhang, Qing Meng, Abdullahi Uwaisu Muhammad  
**Journal/Conference:** Pattern Analysis and Applications  
**Publisher:** Springer London  
**Year:** 2025  
**Indexing:** SCIE  
**Role:** First Author  
**Status:** Published  
**DOI:** [10.1007/s10044-025-01466-1](https://doi.org/10.1007/s10044-025-01466-1)  

### Summary

A transformer-based framework with attention mechanisms for robust person re-identification under challenging visual conditions.
