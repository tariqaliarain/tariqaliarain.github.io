---
title: "Multi-objective Optimization of Ticket Assignment Problem in Large Data Centers"
collection: publications
category: conferences
permalink: /publication/multi-objective-ticket-assignment
excerpt: "A multi-objective optimization approach for ticket assignment, scheduling, and resource allocation in large data centers."
date: 2022-01-01
venue: "CCF Conference on Computer Supported Cooperative Work and Social Computing (ChineseCSCW 2021)"
paperurl: "https://doi.org/10.1007/978-981-19-4549-6_4"
citation: "Tariq Ali Arain, Xiangjie Huang, Zhicheng Cai, Jian Xu. (2022). Multi-objective Optimization of Ticket Assignment Problem in Large Data Centers. CCF Conference on Computer Supported Cooperative Work and Social Computing (ChineseCSCW 2021). https://doi.org/10.1007/978-981-19-4549-6_4"
---

**Authors:** Tariq Ali Arain, Xiangjie Huang, Zhicheng Cai, Jian Xu  
**Journal/Conference:** CCF Conference on Computer Supported Cooperative Work and Social Computing (ChineseCSCW 2021)  
**Publisher:** Springer Nature Singapore  
**Year:** 2022  
**Indexing:** EI / Scopus  
**Role:** First Author  
**Status:** Published  
**DOI:** [10.1007/978-981-19-4549-6_4](https://doi.org/10.1007/978-981-19-4549-6_4)  

### Summary

A multi-objective optimization approach for ticket assignment, scheduling, and resource allocation in large data centers.
